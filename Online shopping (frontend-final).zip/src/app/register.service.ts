import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { UserRegister } from './user-register';
import { UserLogin } from './user-login';
import { Observable } from 'rxjs';
import { ProductModel } from './product-model';
import { Order } from './order';


@Injectable({
  providedIn: 'root'
})
export class RegisterService {


  url:string="http://192.168.13.2:9091/User";
  constructor(private http:HttpClient){}
 

  register(user:UserRegister){
    return this.http.post<any> (this.url,user,{responseType: 'json'});
   
  }
login(login:UserLogin){
 
  return this.http.post<any> (this.url+"/login",login,{responseType: 'json'});
}

fetchProducts() : Observable<ProductModel[]>{
  return this.http.get<ProductModel[]>(this.url+"/fetchproducts",{responseType:'json'})
}

buyNow(productData): Observable<ProductModel[]>{
  return this.http.post<ProductModel[]>(this.url+"/product",productData,{responseType:'json'})

}

generateInvoice(orderId): Observable<Order[]>{

  return this.http.get<Order[]>(this.url+"/"+orderId,{responseType:'json'})

}
}