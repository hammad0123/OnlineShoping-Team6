import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RegisterComponent } from './register/register.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { HomePageComponent } from './home-page/home-page.component';
import { LoginComponent } from './login/login.component';
import { ElectronicsComponent } from './electronics/electronics.component';
import { ClothProductsComponent } from './cloth-products/cloth-products.component';
import { FurnitureComponent } from './furniture/furniture.component';
import { ProductComponent } from './product/product.component';
import { OrderinvoiceComponent } from './orderinvoice/orderinvoice.component';
import { AboutusComponent } from './aboutus/aboutus.component';

@NgModule({
  declarations: [
    AppComponent,
    RegisterComponent,
    HomePageComponent,
    LoginComponent,
    ElectronicsComponent,
    ClothProductsComponent,
    FurnitureComponent,
    ProductComponent,
    OrderinvoiceComponent,
    AboutusComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
