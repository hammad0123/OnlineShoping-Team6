export class CategoryModel {
    constructor(
    public categoryId: number,
    public categoryName: String){}
}
