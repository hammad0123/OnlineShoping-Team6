import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Register-app';
  flag: boolean;

  constructor(private router: Router) { }

  ngOnInit(){
    
    
    let users=localStorage.getItem("userdata");
    //alert(users)
    if(users==null){
      this.flag=true;
    }
    else{
      this.flag=false;
    }
  }

  onLogout(){
    // alert("dsadv");
    localStorage.removeItem("userdata");
    this.ngOnInit()
    this.router.navigate(['login'])
  }
}
