export class Order {

    constructor(
        public orderId: number,
        public productName: String,
        public productId: number,
        public price: number){}
}
