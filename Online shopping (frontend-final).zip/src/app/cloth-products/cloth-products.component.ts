import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cloth-products',
  templateUrl: './cloth-products.component.html',
  styleUrls: ['./cloth-products.component.css']
})
export class ClothProductsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
