import { RetailerModel } from './retailer-model';

describe('RetailerModel', () => {
  it('should create an instance', () => {
    expect(new RetailerModel()).toBeTruthy();
  });
});
