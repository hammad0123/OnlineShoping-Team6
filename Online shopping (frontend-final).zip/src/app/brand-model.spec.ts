import { BrandModel } from './brand-model';

describe('BrandModel', () => {
  it('should create an instance', () => {
    expect(new BrandModel()).toBeTruthy();
  });
});
