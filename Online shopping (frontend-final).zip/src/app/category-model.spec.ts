import { CategoryModel } from './category-model';

describe('CategoryModel', () => {
  it('should create an instance', () => {
    expect(new CategoryModel()).toBeTruthy();
  });
});
