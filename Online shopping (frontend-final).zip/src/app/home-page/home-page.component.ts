import { Component, OnInit } from '@angular/core';
import { RegisterService } from '../register.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home-page',
  templateUrl: './home-page.component.html',
  styleUrls: ['./home-page.component.css']
})
export class HomePageComponent implements OnInit {
  public products = [];

  public productId:number;

  public particularProduct=[];

  public username:string;

  public response:any;

  constructor(private prod:RegisterService,private router: Router) { }

  ngOnInit() {
    this.prod.fetchProducts().subscribe( data =>{
      this.products = data
    }
    );
    
  }
  getProducts(prod:any) {

    let users=localStorage.getItem("userdata");
    //alert(users);
    if(users==null){
      alert('Plaese login first')
      this.router.navigate(['/login'])
    }
    else{
    this.particularProduct=prod;
  
      let productData={
        "userName": JSON.parse(localStorage.getItem("userdata")).userName,
        "productId":prod.productId,
        "productName":prod.productName,
        "price":prod.price
        }
      //alert(JSON.stringify(productData))
      

    this.prod.buyNow(productData).subscribe(data=>{
     this.response=data;
     //alert(this.response.responseCode);
     let url = "invoice?orderId="+this.response.responseCode;

    //  let url = "invoice";
     //alert(url);
     //this.router.navigate([url]);
      this.router.navigate(['/invoice'], { queryParams: { orderId: this.response.responseCode } })

    });
  }}

}
