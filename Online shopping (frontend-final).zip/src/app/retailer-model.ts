export class RetailerModel {

    constructor(
        public retailerId:number,
        public emailId:String,
        public permission:String,
        public retailerName:String,
        public password:String,

    ){}

}
