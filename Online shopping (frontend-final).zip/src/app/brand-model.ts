export class BrandModel {

    constructor(
        public brandId: number,
        public brandName: String){}
}
