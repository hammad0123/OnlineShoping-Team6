import { BrandModel } from './brand-model';
import { CategoryModel } from './category-model';
import { RetailerModel } from './retailer-model';

export class ProductModel {

    constructor(
        public productId:number,
        public productName:String,
        public price:number,
        public productStatus:String,
        public productQuantity:number,
        public retailer:RetailerModel,
        public category:CategoryModel,
        public brand:BrandModel,
        public images:String
    ){}
}
