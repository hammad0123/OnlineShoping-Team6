import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { RegisterService } from '../register.service';

@Component({
  selector: 'app-orderinvoice',
  templateUrl: './orderinvoice.component.html',
  styleUrls: ['./orderinvoice.component.css']
})
export class OrderinvoiceComponent implements OnInit {

  orderId: number;

  public orders= [];

  constructor(private route: ActivatedRoute,private order:RegisterService) { }

  ngOnInit() {

    this.route.queryParams.subscribe(params => {
      //console.log(params);
      this.orderId = params['orderId'];
      // alert("invoice: "+this.orderId);
      // console.log(this.orderId);
      alert("thanks for buying the product");
      this.order.generateInvoice(this.orderId).subscribe(data=>{
        this.orders=data;
      });

    })
  }

}
