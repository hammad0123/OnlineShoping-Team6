import { Component, OnInit } from '@angular/core';
import { FormGroup,FormBuilder,Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { RegisterService } from '../register.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  
  registerForm:FormGroup;
  // url:string="http://localhost:9091/User";
  constructor(private FormBuilder:FormBuilder,private registrationService: RegisterService,
    private router: Router) {} 



    ngOnInit() {
      this.registerForm=this.FormBuilder.group({
        
        userName:['',[Validators.required, Validators.minLength(3)]],
        password:['',Validators.required],
        email:['',Validators.required],
        mobileNo:['',Validators.required],
        address:['',Validators.required]
      });
    }
    addUser(){
      this.registrationService.register(this.registerForm.value)
    .subscribe(data=>{
      this.router.navigate(['/'])
        alert('User is added');
      })
  }
}
