package com.lti.service;

import java.util.ArrayList;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.dao.UserDao;
import com.lti.dao.UserDaoImpl;
import com.lti.model.OrderDetails;
import com.lti.model.Product;
import com.lti.model.User;
import com.lti.model.User1;

@Service("service")
public class UserServiceImpl implements UserService {
	@Autowired
	private UserDao dao;

	@Override
	public boolean addUser(User user) {

		int result = dao.createUser(user);
		if (result == 1)
			return true;
		else
			return false;
	}

	@Override
	public User findUser(User1 user) {
		User result = dao.readUser(user);
		return result;
	}

	@Override
	public List<Product> fetchProduct() {
		List<Product> product=dao.getProducts();
		return dao.getProducts();
		
	}
	
	public int orderParticularProduct(OrderDetails order){
		
		//System.out.println("service");
		
		int result=dao.orderParticularProducts(order);
		
		return result;
 	}

	@Override
	public OrderDetails generateOrderInvoice(int orderId) {
	
		OrderDetails order=dao.createOrderInvoice(orderId);
		return dao.createOrderInvoice(orderId);
		
	}


}
