package com.lti.service;

import java.util.List;

import com.lti.model.OrderDetails;
import com.lti.model.Product;
import com.lti.model.User;
import com.lti.model.User1;

public interface UserService {
	public boolean addUser(User user);

	public User findUser(User1 user);

	
	public List<Product> fetchProduct();
	
	public int orderParticularProduct(OrderDetails order);

	public OrderDetails generateOrderInvoice(int orderId);
	
	
}
