package com.lti.model;




import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope(scopeName = "prototype")
@Entity
@Table(name = "order_details")
@SequenceGenerator(name="seq1",sequenceName="seqid_gen1",allocationSize=1,initialValue=1)
public class OrderDetails {
	
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="seq1")
	@Column(name = "order_id")
	private int orderId;
	@Column(name="user_name")
	private String userName;
	@Column(name = "prod_id")
	private int productId;
	@Column(name = "prod_name")
	private String productName;
	@Column(name = "price")
	private double price;
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
}
