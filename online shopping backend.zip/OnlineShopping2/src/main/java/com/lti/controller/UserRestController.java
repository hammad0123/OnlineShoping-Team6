package com.lti.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.lti.model.OrderDetails;
import com.lti.model.Product;
import com.lti.model.Response;
import com.lti.model.User;
import com.lti.model.User1;
import com.lti.service.UserService;

@RestController
@RequestMapping(path = "User")
@CrossOrigin
public class UserRestController {
	@Autowired
	private UserService service;

	

	// http://localhost:9091/User
	@RequestMapping(path = "/login", method = RequestMethod.POST)
	public User1 readUser(@RequestBody User1 user) {
		ResponseEntity<String> response;
		String username = user.getUserName();
		String password = user.getPassword();
		System.out.println(username + " and " + password);
		User users = service.findUser(user);

		if (users != null) {
			response = new ResponseEntity<>("Login Successful", HttpStatus.CREATED);
		} else {
			response = new ResponseEntity<>("Invalid Login", HttpStatus.INTERNAL_SERVER_ERROR);
		}

		return user;
	}

	// http://localhost:9091/User
	@RequestMapping(method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public User addUser(@RequestBody User user) {
		ResponseEntity<String> response;
		boolean result = service.addUser(user);
		if (result) {
			response = new ResponseEntity<String>("User is added", HttpStatus.CREATED);
		} else {
			response = new ResponseEntity<String>("user is not added", HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return user;
	}

	// http://localhost:9091/User
	@RequestMapping(path="/fetchproducts",method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE)
	public List<Product> fetchProducts(){
		List<Product> prod=service.fetchProduct();
		ResponseEntity<List<Product>> response;
		Response res=new Response<>();
		if(prod!=null && prod.size()>0){
			response=new ResponseEntity<>(prod,HttpStatus.ACCEPTED);
			res.setResponseCode(200);
			res.setResponseMessage("Products fetched");
			res.setResponseObject(prod);
		}else
		{
			response=new ResponseEntity<>(prod,HttpStatus.BAD_REQUEST);
			res.setResponseCode(400);
			res.setResponseMessage("Products does not exists");
			res.setResponseObject(null);
		}
		return prod;
	}
	
	
	
	@RequestMapping(path="/product",method=RequestMethod.POST,consumes=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> fetchParticularProducts(@RequestBody OrderDetails order){
		
		//System.out.println("rest");
		
		int	orderId=service.orderParticularProduct(order);

		ResponseEntity<Response> response;
		Response res=new Response<>();
		if (orderId > 0) {
			response = new ResponseEntity<Response>(new Response<>("order is placed",orderId) , HttpStatus.CREATED);
		} else {
			response = new ResponseEntity<Response>(new Response<>("order is placed",orderId), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;
	}
	
	

	@ExceptionHandler(Exception.class)
	public ResponseEntity<String> handleException(Exception ex) {
		ResponseEntity<String> error = new ResponseEntity<String>(ex.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		return error;
		
		

		
		}
	
	// http://localhost:9091/User/
	@RequestMapping(path="{orderId}",method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE)
	public OrderDetails  generateOrderInvoice(@PathVariable("orderId") int orderId){
		
		OrderDetails order=service.generateOrderInvoice(orderId);
		ResponseEntity<OrderDetails> response;
		Response res=new Response<>();
		//System.out.println("REST");
		if(order!=null){
			response=new ResponseEntity<>(order,HttpStatus.ACCEPTED);
			res.setResponseCode(200);
			res.setResponseMessage("orderdetails fetched");
			res.setResponseObject(order);
		}else
		{
			response=new ResponseEntity<>(order,HttpStatus.BAD_REQUEST);
			res.setResponseCode(400);
			res.setResponseMessage("order does not exists");
			res.setResponseObject(null);
		}
		return order;
	
}
	
}
