package com.lti.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.lti.model.OrderDetails;
import com.lti.model.Product;
import com.lti.model.User;
import com.lti.model.User1;

@Repository
public class UserDaoImpl implements UserDao {
	@PersistenceContext
	private EntityManager entityManager;

	public UserDaoImpl() {

	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED)
	public int createUser(User user) {
		entityManager.persist(user);
		return 1;
	}

	@Override
	@Transactional
	public User readUser(User1 user) {

		TypedQuery<User> query = entityManager
				.createQuery("From User u where u.userName = :username and u.password = :password", User.class);

		query.setParameter("username", user.getUserName());
		query.setParameter("password", user.getPassword());

		User users = query.getSingleResult();


		if (users != null) {
			return users;
		} else {
			return null;
		}
	}

	@Override
	public List<Product> getProducts() {
		String query= "from Product";
		TypedQuery<Product> tyQuery=entityManager.createQuery(query,Product.class);
		List<Product> prod=tyQuery.getResultList();
	//	System.out.println(prod.size());
		return prod;
	}
	
	@Override
	@Transactional(propagation = Propagation.REQUIRED)
	public int orderParticularProducts(OrderDetails order) {
		//System.out.println("dao");
		entityManager.persist(order);
		return order.getOrderId();
	}

	@Override
	public void beginTransaction() {

	}

	@Override
	public void commitTransaction() {

	}

	@Override

	public void rollBackTransaction() {
		entityManager.getTransaction().rollback();
	}

	@Override
	@Transactional
	public OrderDetails createOrderInvoice(int orderId) {
		
		TypedQuery<OrderDetails> tyQuery=entityManager.createQuery("from OrderDetails o where o.orderId= :orderId",OrderDetails.class);
		tyQuery.setParameter("orderId",orderId);
		OrderDetails order=tyQuery.getSingleResult();
		//System.out.println(order);
		return order;
	}


}
