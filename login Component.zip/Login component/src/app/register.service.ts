import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { UserRegister } from './user-register';
import { UserLogin } from './user-login';


@Injectable({
  providedIn: 'root'
})
export class RegisterService {


  url:string="http://192.168.13.2:9091/User";
  constructor(private http:HttpClient){}
 

  register(user:UserRegister){
    return this.http.post<any> (this.url,user,{responseType: 'json'});
   
  }
login(login:UserLogin){
  alert(this.url+"/login");
  return this.http.post<any> (this.url+"/login",login,{responseType: 'json'});
}

}
