export class UserLogin {
    constructor(
    public userName: String,
    public password: String){}
}
