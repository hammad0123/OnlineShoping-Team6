export class UserRegister {
    constructor(
        public UserId:number,
        public UserName: String,
        public password: String,
        public email:String,
        public mobileNo:number,
        public address:String)
       {}
 
}