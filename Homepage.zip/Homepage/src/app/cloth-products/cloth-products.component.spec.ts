import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ClothProductsComponent } from './cloth-products.component';

describe('ClothProductsComponent', () => {
  let component: ClothProductsComponent;
  let fixture: ComponentFixture<ClothProductsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ClothProductsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ClothProductsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
