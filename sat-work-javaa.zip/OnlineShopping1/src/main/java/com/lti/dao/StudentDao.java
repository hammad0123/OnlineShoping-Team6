package com.lti.dao;

import java.util.List;


import com.lti.model.User;

public interface StudentDao {
	public int createUser(User user);

	/*public Student readStuentByRollNumber(int rollNumber);

	public int updateStudent(Student student);

	public int deleteStudentByRollNumber(int rollNumber);*/
	
	//public List<Student> AllStudents();

	public void beginTransaction();

	public void commitTransaction();

	public void rollBackTransaction();
}
