package com.lti.service;

import java.util.List;



import com.lti.model.User;

public interface StudentService {
	public boolean addUser(User user);
/*
	public Student findStudentByRollNumber(int rollNumber);

	public boolean updateStudentDetails(Student student);

	public boolean deleteStudentByRollNumber(int rollnumber);*/

	//public List<Student> AllStudent();
}
